package lib;
public enum PasswordStrength {
    INVALID,
    WEAK,
    MEDIUM,
    STRONG;

    PasswordStrength validate(String string) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'validate'");
    }
}